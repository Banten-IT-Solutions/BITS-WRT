document.write('BITS.NET')
//Sesuaikan
//Jangan Menghapus kode scriptnya