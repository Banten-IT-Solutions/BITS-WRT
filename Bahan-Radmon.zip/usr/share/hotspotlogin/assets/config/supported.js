document.write('BITS-WRT')
//Sesuaikan
//Jangan Menghapus kode scriptnya